```
import weather_forecast

print(forecast(place = "Bangalore"))

```